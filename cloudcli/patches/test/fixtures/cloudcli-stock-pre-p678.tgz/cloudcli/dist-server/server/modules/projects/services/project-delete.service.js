import { promises as fs } from 'node:fs';
import path from 'node:path';
import { projectsDb, sessionsDb } from '../../../modules/database/index.js';
import { AppError } from '../../../shared/utils.js';
function uniqueJsonlPathsFromSessions(sessions) {
    const seen = new Set();
    const result = [];
    for (const row of sessions) {
        const raw = row.jsonl_path?.trim();
        if (!raw) {
            continue;
        }
        const absolute = path.isAbsolute(raw) ? path.normalize(raw) : path.resolve(raw);
        if (seen.has(absolute)) {
            continue;
        }
        seen.add(absolute);
        result.push(absolute);
    }
    return result;
}
async function unlinkJsonlIfExists(filePath) {
    try {
        await fs.unlink(filePath);
    }
    catch (error) {
        const code = error.code;
        if (code === 'ENOENT') {
            return;
        }
        console.warn(`[project-delete] Failed to remove ${filePath}:`, error.message);
    }
}
/**
 * Loads all session rows for the project path and removes each distinct `jsonl_path` file on disk.
 */
export async function deleteSessionJsonlFilesForProjectPath(projectPath) {
    const sessions = sessionsDb.getSessionsByProjectPathIncludingArchived(projectPath);
    // Including the transcripts a session has left behind: editing a message on
    // a provider that rewinds by branching moves the session onto a copy, and
    // the row stops pointing at the file the replaced turns are still in.
    const paths = uniqueJsonlPathsFromSessions([
        ...sessions,
        ...sessions.flatMap((session) => sessionsDb
            .getSupersededTranscriptPaths(session.session_id)
            .map((jsonl_path) => ({ jsonl_path }))),
    ]);
    for (const filePath of paths) {
        await unlinkJsonlIfExists(filePath);
    }
    for (const session of sessions) {
        sessionsDb.clearSupersededProviderSessions(session.session_id);
    }
}
/**
 * - **Soft delete** (`force` false): set `isArchived` on the `projects` row (hide from the active list; DB only).
 * - **Force** (`force` true): for each session row for that `project_path`, delete the file at `jsonl_path`
 *   (when set), then remove session rows and the `projects` row.
 */
export async function deleteOrArchiveProject(projectId, force) {
    const row = projectsDb.getProjectById(projectId);
    if (!row) {
        throw new AppError(`Unknown projectId: ${projectId}`, {
            code: 'PROJECT_NOT_FOUND',
            statusCode: 404,
        });
    }
    if (!force) {
        projectsDb.updateProjectIsArchivedById(projectId, true);
        return;
    }
    await deleteSessionJsonlFilesForProjectPath(row.project_path);
    sessionsDb.deleteSessionsByProjectPath(row.project_path);
    projectsDb.deleteProjectById(projectId);
}
/**
 * Restores one archived project row back into the active project list.
 */
export function restoreArchivedProject(projectId) {
    const row = projectsDb.getProjectById(projectId);
    if (!row) {
        throw new AppError(`Unknown projectId: ${projectId}`, {
            code: 'PROJECT_NOT_FOUND',
            statusCode: 404,
        });
    }
    projectsDb.updateProjectIsArchivedById(projectId, false);
}
//# sourceMappingURL=project-delete.service.js.map