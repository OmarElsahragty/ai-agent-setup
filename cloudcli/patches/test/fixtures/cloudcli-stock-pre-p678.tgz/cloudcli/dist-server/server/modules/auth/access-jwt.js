// Cloudflare Access JWT validation at the CloudCLI origin (patch P5, FP-2 / finding S1).
// Validates the Cf-Access-Jwt-Assertion header (fallback: CF_Authorization cookie)
// using node:crypto only (JWK -> createPublicKey, RS256 via createVerify).
// Enabled ONLY when BOTH CF_ACCESS_AUD and CF_ACCESS_TEAM_DOMAIN are set; when either
// is unset every export is a pass-through so local/offline behaviour is unchanged.
// Fail closed: missing/invalid assertion or certs-fetch failure always rejects.
// No loopback bypass. Tokens are never logged (error messages carry reason codes only).
import { createPublicKey, createVerify } from 'node:crypto';

const CLOCK_SKEW_SECONDS = 60;
const CERTS_CACHE_MS = 60 * 60 * 1000;
const CERTS_TIMEOUT_MS = 5000;
const MAX_TOKEN_CHARS = 16384;

const state = { keys: new Map(), fetchedAt: 0, inFlight: null };

export function resetAccessStateForTesting() {
    state.keys = new Map();
    state.fetchedAt = 0;
    state.inFlight = null;
}

function accessConfig() {
    const aud = (process.env.CF_ACCESS_AUD || '').trim();
    let team = (process.env.CF_ACCESS_TEAM_DOMAIN || '').trim().toLowerCase();
    team = team.replace(/^https?:\/\//, '').replace(/\/+$/, '');
    if (!aud || !team || team.includes('/')) {
        return null;
    }
    return { aud, team, issuer: `https://${team}` };
}

export function isAccessAuthEnabled() {
    return accessConfig() !== null;
}

function extractAccessToken(headers) {
    const h = headers || {};
    const headerToken = h['cf-access-jwt-assertion'];
    if (typeof headerToken === 'string' && headerToken.length > 0) {
        return headerToken;
    }
    const cookie = h.cookie;
    if (typeof cookie === 'string') {
        for (const part of cookie.split(';')) {
            const eq = part.indexOf('=');
            if (eq > 0 && part.slice(0, eq).trim() === 'CF_Authorization') {
                const value = part.slice(eq + 1).trim();
                if (value) {
                    return value;
                }
            }
        }
    }
    return null;
}

function decodeSegment(segment, what) {
    let parsed;
    try {
        parsed = JSON.parse(Buffer.from(segment, 'base64url').toString('utf8'));
    }
    catch {
        throw new Error(`malformed ${what}`);
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error(`malformed ${what}`);
    }
    return parsed;
}

async function fetchCerts(cfg, { force = false } = {}) {
    if (state.inFlight) {
        return state.inFlight;
    }
    if (!force && state.fetchedAt > 0 && Date.now() - state.fetchedAt < CERTS_CACHE_MS) {
        return state.keys;
    }
    const load = (async () => {
        const url = `https://${cfg.team}/cdn-cgi/access/certs`;
        const response = await fetch(url, { signal: AbortSignal.timeout(CERTS_TIMEOUT_MS) });
        if (!response.ok) {
            throw new Error(`certs endpoint returned HTTP ${response.status}`);
        }
        const body = await response.json();
        const keys = new Map();
        // Accept both the JWKS shape ({keys:[{kid,kty,n,e}]}) and the legacy
        // {public_certs:[{kid,cert}]} PEM shape from /cdn-cgi/access/certs.
        for (const entry of body.keys ?? body.public_certs ?? []) {
            if (!entry || typeof entry.kid !== 'string' || entry.kid.length === 0) {
                continue;
            }
            if (typeof entry.cert === 'string') {
                keys.set(entry.kid, createPublicKey(entry.cert));
            }
            else if (entry.kty === 'RSA' && typeof entry.n === 'string' && typeof entry.e === 'string') {
                keys.set(entry.kid, createPublicKey({ key: entry, format: 'jwk' }));
            }
        }
        if (keys.size === 0) {
            throw new Error('certs response contained no usable keys');
        }
        state.keys = keys;
        state.fetchedAt = Date.now();
        return keys;
    })();
    state.inFlight = load;
    try {
        return await load;
    }
    finally {
        if (state.inFlight === load) {
            state.inFlight = null;
        }
    }
}

export async function verifyAssertion(rawToken) {
    const cfg = accessConfig();
    if (!cfg) {
        throw new Error('cloudflare access validation is not configured');
    }
    if (typeof rawToken !== 'string' || rawToken.length === 0) {
        throw new Error('missing access assertion');
    }
    if (rawToken.length > MAX_TOKEN_CHARS) {
        throw new Error('access assertion too large');
    }
    const segments = rawToken.split('.');
    if (segments.length !== 3) {
        throw new Error('malformed access assertion');
    }
    const [encHeader, encPayload, encSignature] = segments;
    const header = decodeSegment(encHeader, 'access assertion header');
    const payload = decodeSegment(encPayload, 'access assertion payload');
    if (header.alg !== 'RS256') {
        throw new Error('only RS256 access assertions are accepted');
    }
    if (typeof header.kid !== 'string' || header.kid.length === 0) {
        throw new Error('access assertion header has no kid');
    }
    if (payload.iss !== cfg.issuer) {
        throw new Error('access assertion issuer mismatch');
    }
    const audience = payload.aud;
    const audienceOk = Array.isArray(audience) ? audience.includes(cfg.aud) : audience === cfg.aud;
    if (!audienceOk) {
        throw new Error('access assertion audience mismatch');
    }
    const now = Math.floor(Date.now() / 1000);
    if (typeof payload.exp !== 'number' || now >= payload.exp + CLOCK_SKEW_SECONDS) {
        throw new Error('access assertion expired');
    }
    if (typeof payload.nbf !== 'number' || now < payload.nbf - CLOCK_SKEW_SECONDS) {
        throw new Error('access assertion not yet valid');
    }
    let keys = await fetchCerts(cfg);
    let key = keys.get(header.kid);
    if (!key) {
        // Key rotation: refetch once on unknown kid (still single-flight).
        keys = await fetchCerts(cfg, { force: true });
        key = keys.get(header.kid);
        if (!key) {
            throw new Error('unknown access assertion signing key');
        }
    }
    const signature = Buffer.from(encSignature, 'base64url');
    const verifier = createVerify('RSA-SHA256');
    verifier.update(`${encHeader}.${encPayload}`);
    if (!verifier.verify(key, signature)) {
        throw new Error('access assertion signature mismatch');
    }
    return payload;
}

// Express middleware mounted app-wide BEFORE every route (incl. /health).
export async function accessRestMiddleware(req, res, next) {
    if (!isAccessAuthEnabled()) {
        next();
        return;
    }
    try {
        await verifyAssertion(extractAccessToken(req.headers));
        next();
    }
    catch (error) {
        console.warn('[cloudflare-access] rejected request:', error instanceof Error ? error.message : 'unknown error');
        res.status(401).json({ error: 'Cloudflare Access validation failed', code: 'CF_ACCESS_DENIED' });
    }
}

// Wraps the WebSocketServer verifyClient hook (runs BEFORE the 'connection'
// handler, so /shell and /plugin-ws rejections happen before any pty/plugin
// spawn). The patched arrow has arity 2, so ws 8.x always uses callback mode;
// rejection aborts the upgrade with HTTP 401 and destroys the socket.
export function guardAccessWebSocketUpgrade(info, callback, fallbackDecision) {
    if (!isAccessAuthEnabled()) {
        let allowed = false;
        try {
            allowed = !!fallbackDecision();
        }
        catch {
            allowed = false;
        }
        finishWebSocketGuard(callback, allowed);
        return allowed;
    }
    void (async () => {
        let allowed = false;
        try {
            await verifyAssertion(extractAccessToken(info?.req?.headers));
            allowed = !!fallbackDecision();
        }
        catch {
            allowed = false;
        }
        finishWebSocketGuard(callback, allowed);
    })();
    return undefined;
}

function finishWebSocketGuard(callback, allowed) {
    if (typeof callback !== 'function') {
        return;
    }
    if (allowed) {
        callback(true);
    }
    else {
        callback(false, 401, 'Unauthorized');
    }
}
