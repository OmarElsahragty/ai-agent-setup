import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { closeConnection, initializeDatabase, scheduledMessagesDb, sessionDraftsDb, sessionsDb, userDb } from '../../../modules/database/index.js';
import { dispatchDueScheduledMessages, dispatchQueuedMessages } from '../../../modules/scheduled-messages/services/scheduled-message-dispatcher.service.js';
import { scheduledMessagesService } from '../../../modules/scheduled-messages/services/scheduled-messages.service.js';
import { chatRunRegistry } from '../../../modules/websocket/index.js';
const SESSION_ID = 'scheduled-session';
async function withIsolatedDatabase(runTest) {
    const previousDatabasePath = process.env.DATABASE_PATH;
    const tempDirectory = await mkdtemp(path.join(tmpdir(), 'scheduled-messages-'));
    closeConnection();
    process.env.DATABASE_PATH = path.join(tempDirectory, 'auth.db');
    await initializeDatabase();
    try {
        const user = userDb.createUser('scheduler', 'hash');
        sessionsDb.createAppSession(SESSION_ID, 'claude', tempDirectory, 'Scheduled session');
        await runTest(Number(user.id));
    }
    finally {
        chatRunRegistry.clearAll();
        closeConnection();
        if (previousDatabasePath === undefined) {
            delete process.env.DATABASE_PATH;
        }
        else {
            process.env.DATABASE_PATH = previousDatabasePath;
        }
        await rm(tempDirectory, { recursive: true, force: true });
    }
}
function createRuntime(runs, behaviour = 'ok', aborts = []) {
    return {
        hasRuntime: () => true,
        run: async (provider, command, options) => {
            if (behaviour === 'throw') {
                throw new Error('provider exploded');
            }
            runs.push({ provider, command, options });
        },
        abort: async (_provider, sessionId) => {
            aborts.push(sessionId);
            return true;
        },
    };
}
test('a message due in the past is sent on the next pass, not skipped', async () => {
    await withIsolatedDatabase(async (userId) => {
        // The server was down when this came due.
        scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'run the nightly checks',
            scheduledFor: new Date(Date.now() - 60_000).toISOString(),
        });
        const runs = [];
        const sent = await dispatchDueScheduledMessages(createRuntime(runs));
        assert.equal(sent, 1);
        assert.equal(runs.length, 1);
        assert.equal(runs[0].command, 'run the nightly checks');
        assert.equal(scheduledMessagesDb.listForSession(userId, SESSION_ID)[0].status, 'sent');
    });
});
test('a queued message is sent by the server without a browser connection', async () => {
    await withIsolatedDatabase(async (userId) => {
        sessionDraftsDb.saveDraft(userId, SESSION_ID, {
            text: '',
            queuedMessage: {
                content: 'continue on the VPS',
                options: { model: 'claude-opus-5' },
                attachments: [{ path: '/tmp/upload.png' }],
            },
        });
        const runs = [];
        assert.equal(await dispatchQueuedMessages(createRuntime(runs)), 1);
        assert.equal(runs.length, 1);
        assert.equal(runs[0].command, 'continue on the VPS');
        assert.equal(runs[0].options.model, 'claude-opus-5');
        assert.deepEqual(runs[0].options.attachments, []);
        assert.equal(sessionDraftsDb.getDrafts(userId).length, 0);
    });
});
test('a queued message stays pending while its session is busy', async () => {
    await withIsolatedDatabase(async (userId) => {
        sessionDraftsDb.saveDraft(userId, SESSION_ID, {
            text: '',
            queuedMessage: { content: 'send after this run' },
        });
        chatRunRegistry.startRun({
            appSessionId: SESSION_ID,
            provider: 'claude',
            providerSessionId: null,
            connection: null,
            userId,
        });
        const runs = [];
        assert.equal(await dispatchQueuedMessages(createRuntime(runs)), 0);
        assert.equal(runs.length, 0);
        assert.deepEqual(sessionDraftsDb.getDrafts(userId)[0]?.queuedMessage, {
            content: 'send after this run',
        });
    });
});
test('a due message interrupts a run in progress instead of failing', async () => {
    await withIsolatedDatabase(async (userId) => {
        scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'the schedule wins',
            scheduledFor: new Date(Date.now() - 1_000).toISOString(),
        });
        chatRunRegistry.startRun({
            appSessionId: SESSION_ID,
            provider: 'claude',
            providerSessionId: null,
            connection: null,
            userId,
        });
        const runs = [];
        const aborts = [];
        assert.equal(await dispatchDueScheduledMessages(createRuntime(runs, 'ok', aborts)), 1);
        assert.deepEqual(aborts, [SESSION_ID]);
        assert.equal(runs.length, 1);
        assert.equal(runs[0].command, 'the schedule wins');
        assert.equal(scheduledMessagesDb.listForSession(userId, SESSION_ID)[0].status, 'sent');
    });
});
test('a message that is not due yet is left alone', async () => {
    await withIsolatedDatabase(async (userId) => {
        scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'later',
            scheduledFor: new Date(Date.now() + 3_600_000).toISOString(),
        });
        const runs = [];
        assert.equal(await dispatchDueScheduledMessages(createRuntime(runs)), 0);
        assert.equal(runs.length, 0);
        assert.equal(scheduledMessagesDb.listForSession(userId, SESSION_ID)[0].status, 'pending');
    });
});
test('a due message is claimed once, so overlapping passes cannot double-send it', async () => {
    await withIsolatedDatabase(async (userId) => {
        scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'only once',
            scheduledFor: new Date(Date.now() - 1_000).toISOString(),
        });
        const runs = [];
        const runtime = createRuntime(runs);
        await Promise.all([
            dispatchDueScheduledMessages(runtime),
            dispatchDueScheduledMessages(runtime),
        ]);
        assert.equal(runs.length, 1);
    });
});
test('the composer settings it was scheduled with travel with it', async () => {
    await withIsolatedDatabase(async (userId) => {
        scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'with options',
            options: { model: 'claude-opus-5', permissionMode: 'plan' },
            scheduledFor: new Date(Date.now() - 1_000).toISOString(),
        });
        const runs = [];
        await dispatchDueScheduledMessages(createRuntime(runs));
        assert.equal(runs[0].options.model, 'claude-opus-5');
        assert.equal(runs[0].options.permissionMode, 'plan');
    });
});
test('a provider failure is recorded on the message instead of vanishing', async () => {
    await withIsolatedDatabase(async (userId) => {
        scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'will fail',
            scheduledFor: new Date(Date.now() - 1_000).toISOString(),
        });
        await dispatchDueScheduledMessages(createRuntime([], 'throw'));
        const row = scheduledMessagesDb.listForSession(userId, SESSION_ID)[0];
        assert.equal(row.status, 'failed');
        assert.match(row.failure_reason ?? '', /provider exploded/);
    });
});
test('a cancelled message never fires', async () => {
    await withIsolatedDatabase(async (userId) => {
        const scheduled = scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'never mind',
            scheduledFor: new Date(Date.now() - 1_000).toISOString(),
        });
        scheduledMessagesService.cancel(userId, scheduled.id);
        const runs = [];
        assert.equal(await dispatchDueScheduledMessages(createRuntime(runs)), 0);
        assert.equal(runs.length, 0);
    });
});
test('a failed message can be dismissed, and stays dismissed', async () => {
    await withIsolatedDatabase(async (userId) => {
        const scheduled = scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'will fail',
            scheduledFor: new Date(Date.now() - 1_000).toISOString(),
        });
        await dispatchDueScheduledMessages(createRuntime([], 'throw'));
        assert.equal(scheduledMessagesDb.listForSession(userId, SESSION_ID)[0].status, 'failed');
        scheduledMessagesService.cancel(userId, scheduled.id);
        assert.equal(scheduledMessagesDb.listForSession(userId, SESSION_ID)[0].status, 'cancelled');
    });
});
test('cancelling something that already fired is refused', async () => {
    await withIsolatedDatabase(async (userId) => {
        const scheduled = scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'gone',
            scheduledFor: new Date(Date.now() - 1_000).toISOString(),
        });
        await dispatchDueScheduledMessages(createRuntime([]));
        assert.throws(() => scheduledMessagesService.cancel(userId, scheduled.id), (error) => error.code === 'SCHEDULED_MESSAGE_NOT_PENDING');
    });
});
test('one user cannot cancel another user\'s scheduled message', async () => {
    await withIsolatedDatabase(async (userId) => {
        const scheduled = scheduledMessagesService.schedule({
            userId,
            sessionId: SESSION_ID,
            content: 'mine',
            scheduledFor: new Date(Date.now() + 3_600_000).toISOString(),
        });
        assert.throws(() => scheduledMessagesService.cancel(userId + 1, scheduled.id), (error) => error.code === 'SCHEDULED_MESSAGE_NOT_PENDING');
        assert.equal(scheduledMessagesDb.listForSession(userId, SESSION_ID)[0].status, 'pending');
    });
});
test('scheduling validates its input', async () => {
    await withIsolatedDatabase(async (userId) => {
        const base = { userId, sessionId: SESSION_ID, scheduledFor: new Date(Date.now() + 1000).toISOString() };
        assert.throws(() => scheduledMessagesService.schedule({ ...base, content: '   ' }), (error) => error.code === 'CONTENT_REQUIRED');
        assert.throws(() => scheduledMessagesService.schedule({ ...base, content: 'hi', scheduledFor: 'not a date' }), (error) => error.code === 'INVALID_SCHEDULE_TIME');
        assert.throws(() => scheduledMessagesService.schedule({
            ...base,
            content: 'hi',
            scheduledFor: new Date(Date.now() + 400 * 24 * 3600 * 1000).toISOString(),
        }), (error) => error.code === 'SCHEDULE_TOO_FAR_AHEAD');
        assert.throws(() => scheduledMessagesService.schedule({ ...base, sessionId: 'nope', content: 'hi' }), (error) => error.code === 'SESSION_NOT_FOUND');
    });
});
//# sourceMappingURL=scheduled-messages.test.js.map