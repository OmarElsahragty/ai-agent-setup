import { readFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import spawn from 'cross-spawn';
import { resolveClaudeCodeExecutablePath } from '../../../../shared/claude-cli-path.js';
import { readObjectRecord, readOptionalString } from '../../../../shared/utils.js';
const hasErrorCode = (error, code) => (error instanceof Error && 'code' in error && error.code === code);
export class ClaudeProviderAuth {
    /**
     * Checks whether the Claude Code CLI is available on this host.
     */
    checkInstalled() {
        // cross-spawn resolves shims and PATHEXT itself, so the bare command is a
        // usable fallback here even where the SDK's raw spawn could not use it.
        const cliPath = resolveClaudeCodeExecutablePath(process.env.CLAUDE_CLI_PATH) ?? 'claude';
        try {
            spawn.sync(cliPath, ['--version'], { stdio: 'ignore', timeout: 5000 });
            return true;
        }
        catch {
            return false;
        }
    }
    /**
     * Returns Claude installation and credential status using Claude Code's auth priority.
     */
    async getStatus() {
        const installed = this.checkInstalled();
        if (!installed) {
            return {
                installed,
                provider: 'claude',
                authenticated: false,
                email: null,
                method: null,
                error: 'Claude Code CLI is not installed',
            };
        }
        const credentials = await this.checkCredentials();
        return {
            installed,
            provider: 'claude',
            authenticated: credentials.authenticated,
            email: credentials.authenticated ? credentials.email || 'Authenticated' : credentials.email,
            method: credentials.method,
            error: credentials.authenticated ? undefined : credentials.error || 'Not authenticated',
        };
    }
    /**
     * Reads Claude settings env values that the CLI can use even when the server process env is empty.
     */
    async loadSettingsEnv() {
        try {
            const settingsPath = path.join(os.homedir(), '.claude', 'settings.json');
            const content = await readFile(settingsPath, 'utf8');
            const settings = readObjectRecord(JSON.parse(content));
            return readObjectRecord(settings?.env) ?? {};
        }
        catch {
            return {};
        }
    }
    /**
     * Checks Claude credentials in the same priority order used by Claude Code.
     */
    async checkCredentials() {
        const missingCredentialsError = 'Claude CLI is not authenticated. Run claude /login or configure ANTHROPIC_API_KEY.';
        if (process.env.ANTHROPIC_AUTH_TOKEN?.trim()) {
            return { authenticated: true, email: 'Auth Token', method: 'api_key' };
        }
        if (process.env.ANTHROPIC_API_KEY?.trim()) {
            return { authenticated: true, email: 'API Key Auth', method: 'api_key' };
        }
        const settingsEnv = await this.loadSettingsEnv();
        if (readOptionalString(settingsEnv.ANTHROPIC_API_KEY)) {
            return { authenticated: true, email: 'API Key Auth', method: 'api_key' };
        }
        if (readOptionalString(settingsEnv.ANTHROPIC_AUTH_TOKEN)) {
            return { authenticated: true, email: 'Configured via settings.json', method: 'api_key' };
        }
        if (process.env.CLAUDE_CODE_OAUTH_TOKEN?.trim()) {
            return { authenticated: true, email: 'OAuth Token (long-lived)', method: 'environment' };
        }
        if (readOptionalString(settingsEnv.CLAUDE_CODE_OAUTH_TOKEN)) {
            return { authenticated: true, email: 'OAuth Token (long-lived)', method: 'environment' };
        }
        try {
            const credPath = path.join(os.homedir(), '.claude', '.credentials.json');
            const content = await readFile(credPath, 'utf8');
            const creds = readObjectRecord(JSON.parse(content)) ?? {};
            const oauth = readObjectRecord(creds.claudeAiOauth);
            const accessToken = readOptionalString(oauth?.accessToken);
            if (accessToken) {
                const expiresAt = typeof oauth?.expiresAt === 'number' ? oauth.expiresAt : undefined;
                const email = readOptionalString(creds.email) ?? readOptionalString(creds.user) ?? null;
                if (!expiresAt || Date.now() < expiresAt) {
                    return {
                        authenticated: true,
                        email,
                        method: 'credentials_file',
                    };
                }
                // `accessToken` is short-lived (hours). Claude Code renews it silently
                // from `refreshToken` on the next CLI invocation, so an expired access
                // token alongside a live refresh token is still a working login. Before
                // this check, a still-signed-in account read as "login has expired"
                // until something else happened to run the CLI — which is why opening
                // the Shell tab and coming back made Settings flip to Connected.
                const refreshToken = readOptionalString(oauth?.refreshToken);
                const refreshTokenExpiresAt = typeof oauth?.refreshTokenExpiresAt === 'number'
                    ? oauth.refreshTokenExpiresAt
                    : undefined;
                if (refreshToken && (!refreshTokenExpiresAt || Date.now() < refreshTokenExpiresAt)) {
                    return {
                        authenticated: true,
                        email,
                        method: 'credentials_file',
                    };
                }
                return {
                    authenticated: false,
                    email: null,
                    method: null,
                    error: 'Claude login has expired. Run claude /login again.',
                };
            }
            return {
                authenticated: false,
                email: null,
                method: null,
                error: missingCredentialsError,
            };
        }
        catch (error) {
            let errorMessage = 'Unable to read Claude credentials. Run claude /login again.';
            if (hasErrorCode(error, 'ENOENT')) {
                errorMessage = missingCredentialsError;
            }
            else if (error instanceof SyntaxError) {
                errorMessage = 'Claude credentials are unreadable. Run claude /login again.';
            }
            return {
                authenticated: false,
                email: null,
                method: null,
                error: errorMessage,
            };
        }
    }
}
//# sourceMappingURL=claude-auth.provider.js.map